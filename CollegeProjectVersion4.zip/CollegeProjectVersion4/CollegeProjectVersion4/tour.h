#ifndef TOUR_H
#define TOUR_H

#include <QDialog>
#include <QPushButton>
#include <QDebug>
#include <QString>
#include <QVector>

namespace Ui {
class tour;
}

class tour : public QDialog
{
    Q_OBJECT

public:
    tour(QVector<QString> collegeNames);
    explicit tour(QVector<QString> collegeNames, QWidget *parent = nullptr);
    ~tour();

private slots:
    void on_returnButton_clicked();

    void on_nextCollege_0_clicked();

    void on_previousCollege_1_clicked();

    void on_nextCollege_1_clicked();

    void on_previousCOllege_2_clicked();

    void on_nextCollege_2_clicked();

    void on_previousCollege_3_clicked();

    void on_nextCollege_3_clicked();

    void on_previousCollege_4_clicked();

    void on_nextCollege_4_clicked();

    void on_previousCollege_5_clicked();

    void on_nextCollege_5_clicked();

    void on_previousCollege_6_clicked();

    void on_nextCollege_6_clicked();

    void on_previousCollege_7_clicked();

    void on_nextCollege_7_clicked();

    void on_previousCollege_8_clicked();

    void on_nextCollege_8_clicked();

    void on_previousCollege_9_clicked();

    void on_nextCollege_9_clicked();

    void on_previousCollege_10_clicked();

    void on_nextCollege_10_clicked();

    void on_previousCollege_11_clicked();

    void on_nextCollege_11_clicked();

    void on_previousCollege_12_clicked();

private:
    Ui::tour *ui;
};

#endif // TOUR_H
