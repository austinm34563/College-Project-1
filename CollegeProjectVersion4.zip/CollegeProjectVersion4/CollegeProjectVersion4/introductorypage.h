#ifndef INTRODUCTORYPAGE_H
#define INTRODUCTORYPAGE_H

#include <QMainWindow>
#include "adminloginscreen.h"
#include "studentconsole.h"

namespace Ui {
class IntroductoryPage;
}

class IntroductoryPage : public QMainWindow
{
    Q_OBJECT

public:
    explicit IntroductoryPage(QWidget *parent = nullptr);
    ~IntroductoryPage();

private slots:
    void on_adminLoginButton_clicked();

    void on_startButton_clicked();

public:
    AdminLoginScreen *adminPtr;
    StudentConsole *studentPtr;
private:
    Ui::IntroductoryPage *ui;
};

#endif // INTRODUCTORYPAGE_H
