/********************************************************************************
** Form generated from reading UI file 'studentconsole.ui'
**
** Created by: Qt User Interface Compiler version 5.12.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_STUDENTCONSOLE_H
#define UI_STUDENTCONSOLE_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QListView>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QTableView>
#include <QtWidgets/QTextBrowser>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_StudentConsole
{
public:
    QTabWidget *tabWidget;
    QWidget *tab;
    QLabel *label;
    QTableView *souvDataTable;
    QLabel *label_2;
    QListView *dataTable;
    QLabel *label_3;
    QLabel *label_4;
    QPushButton *viewSouvButton;
    QLabel *label_12;
    QComboBox *collegeComboBox;
    QWidget *tab_3;
    QTableView *distancesTable;
    QLabel *label_8;
    QWidget *tab_5;
    QTextBrowser *CollegePathBrowserUCI;
    QLabel *distanceLable_3;
    QLabel *collegeAmountLableUCI;
    QLabel *collegeAmountLable_5;
    QLabel *label_11;
    QWidget *tab_4;
    QLabel *label_9;
    QLabel *collegeAmountLableASU;
    QLabel *distanceLable_2;
    QLabel *collegeAmountLable_4;
    QTextBrowser *CollegePathBrowserASU;
    QLabel *label_10;
    QSpinBox *collegeAmountBox;
    QPushButton *tripInfoASUButton;
    QPushButton *startTourButton_2;
    QWidget *tab_2;
    QLabel *label_5;
    QComboBox *comboBox;
    QLabel *label_6;
    QLabel *label_7;
    QPushButton *tripInformationButton;
    QLabel *distanceLable;
    QLabel *collegeAmountLable;
    QComboBox *comboBox2;
    QComboBox *comboBox3;
    QComboBox *comboBox4;
    QComboBox *comboBox5;
    QComboBox *comboBox6;
    QComboBox *comboBox7;
    QComboBox *comboBox8;
    QComboBox *comboBox9;
    QComboBox *comboBox10;
    QComboBox *comboBox11;
    QComboBox *comboBox12;
    QCheckBox *checkBox2;
    QCheckBox *checkBox3;
    QCheckBox *checkBox5;
    QCheckBox *checkBox4;
    QCheckBox *checkBox6;
    QCheckBox *checkBox7;
    QCheckBox *checkBox9;
    QCheckBox *checkBox8;
    QCheckBox *checkBox12;
    QCheckBox *checkBox10;
    QCheckBox *checkBox11;
    QLabel *collegeAmountLable_2;
    QTextBrowser *CollegePathBrowser;
    QCheckBox *checkBox13;
    QComboBox *comboBox13;
    QPushButton *startTourButton;
    QWidget *tab_6;
    QLabel *distanceLable_4;
    QTextBrowser *CollegePathBrowserSaddleback;
    QLabel *collegeAmountLableSaddleback;
    QLabel *collegeAmountLable_6;
    QLabel *label_13;
    QPushButton *startTourButton_3;
    QPushButton *pushButton;

    void setupUi(QDialog *StudentConsole)
    {
        if (StudentConsole->objectName().isEmpty())
            StudentConsole->setObjectName(QString::fromUtf8("StudentConsole"));
        StudentConsole->resize(1083, 644);
        tabWidget = new QTabWidget(StudentConsole);
        tabWidget->setObjectName(QString::fromUtf8("tabWidget"));
        tabWidget->setGeometry(QRect(10, 0, 1061, 641));
        tab = new QWidget();
        tab->setObjectName(QString::fromUtf8("tab"));
        label = new QLabel(tab);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(480, 10, 131, 31));
        label->setStyleSheet(QString::fromUtf8("font: 30pt \"Lao Sangam MN\";"));
        souvDataTable = new QTableView(tab);
        souvDataTable->setObjectName(QString::fromUtf8("souvDataTable"));
        souvDataTable->setGeometry(QRect(470, 140, 561, 331));
        label_2 = new QLabel(tab);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(430, 50, 251, 16));
        label_2->setStyleSheet(QString::fromUtf8("font: 14pt \".SF NS Text\";"));
        dataTable = new QListView(tab);
        dataTable->setObjectName(QString::fromUtf8("dataTable"));
        dataTable->setGeometry(QRect(30, 140, 381, 431));
        dataTable->setStyleSheet(QString::fromUtf8("font: 87 16pt \"Lao Sangam MN\";"));
        label_3 = new QLabel(tab);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(170, 110, 81, 16));
        label_4 = new QLabel(tab);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(700, 110, 101, 16));
        viewSouvButton = new QPushButton(tab);
        viewSouvButton->setObjectName(QString::fromUtf8("viewSouvButton"));
        viewSouvButton->setGeometry(QRect(830, 510, 141, 32));
        viewSouvButton->setStyleSheet(QString::fromUtf8("background-color: rgb(227, 255, 204);"));
        label_12 = new QLabel(tab);
        label_12->setObjectName(QString::fromUtf8("label_12"));
        label_12->setGeometry(QRect(480, 485, 121, 21));
        label_12->setStyleSheet(QString::fromUtf8("font: 16pt \".SF NS Text\";"));
        collegeComboBox = new QComboBox(tab);
        collegeComboBox->setObjectName(QString::fromUtf8("collegeComboBox"));
        collegeComboBox->setGeometry(QRect(590, 480, 211, 32));
        tabWidget->addTab(tab, QString());
        tab_3 = new QWidget();
        tab_3->setObjectName(QString::fromUtf8("tab_3"));
        distancesTable = new QTableView(tab_3);
        distancesTable->setObjectName(QString::fromUtf8("distancesTable"));
        distancesTable->setGeometry(QRect(40, 50, 991, 541));
        label_8 = new QLabel(tab_3);
        label_8->setObjectName(QString::fromUtf8("label_8"));
        label_8->setGeometry(QRect(40, 10, 681, 31));
        label_8->setStyleSheet(QString::fromUtf8("font: 30pt \"Lao Sangam MN\";"));
        tabWidget->addTab(tab_3, QString());
        tab_5 = new QWidget();
        tab_5->setObjectName(QString::fromUtf8("tab_5"));
        CollegePathBrowserUCI = new QTextBrowser(tab_5);
        CollegePathBrowserUCI->setObjectName(QString::fromUtf8("CollegePathBrowserUCI"));
        CollegePathBrowserUCI->setGeometry(QRect(80, 240, 541, 341));
        CollegePathBrowserUCI->setStyleSheet(QString::fromUtf8("font: 20pt \"Lao Sangam MN\";"));
        distanceLable_3 = new QLabel(tab_5);
        distanceLable_3->setObjectName(QString::fromUtf8("distanceLable_3"));
        distanceLable_3->setGeometry(QRect(80, 100, 531, 16));
        distanceLable_3->setStyleSheet(QString::fromUtf8("font: 20pt \"Lao Sangam MN\";"));
        collegeAmountLableUCI = new QLabel(tab_5);
        collegeAmountLableUCI->setObjectName(QString::fromUtf8("collegeAmountLableUCI"));
        collegeAmountLableUCI->setGeometry(QRect(80, 150, 481, 31));
        collegeAmountLableUCI->setStyleSheet(QString::fromUtf8("font: 20pt \"Lao Sangam MN\";"));
        collegeAmountLable_5 = new QLabel(tab_5);
        collegeAmountLable_5->setObjectName(QString::fromUtf8("collegeAmountLable_5"));
        collegeAmountLable_5->setGeometry(QRect(80, 210, 141, 31));
        collegeAmountLable_5->setStyleSheet(QString::fromUtf8("font: 20pt \"Lao Sangam MN\";"));
        label_11 = new QLabel(tab_5);
        label_11->setObjectName(QString::fromUtf8("label_11"));
        label_11->setGeometry(QRect(250, 20, 441, 41));
        label_11->setStyleSheet(QString::fromUtf8("font: 30pt \"Lao Sangam MN\";"));
        tabWidget->addTab(tab_5, QString());
        tab_4 = new QWidget();
        tab_4->setObjectName(QString::fromUtf8("tab_4"));
        label_9 = new QLabel(tab_4);
        label_9->setObjectName(QString::fromUtf8("label_9"));
        label_9->setGeometry(QRect(340, 20, 491, 41));
        label_9->setStyleSheet(QString::fromUtf8("font: 30pt \"Lao Sangam MN\";"));
        collegeAmountLableASU = new QLabel(tab_4);
        collegeAmountLableASU->setObjectName(QString::fromUtf8("collegeAmountLableASU"));
        collegeAmountLableASU->setGeometry(QRect(510, 150, 481, 31));
        collegeAmountLableASU->setStyleSheet(QString::fromUtf8("font: 20pt \"Lao Sangam MN\";"));
        distanceLable_2 = new QLabel(tab_4);
        distanceLable_2->setObjectName(QString::fromUtf8("distanceLable_2"));
        distanceLable_2->setGeometry(QRect(510, 100, 531, 16));
        distanceLable_2->setStyleSheet(QString::fromUtf8("font: 20pt \"Lao Sangam MN\";"));
        collegeAmountLable_4 = new QLabel(tab_4);
        collegeAmountLable_4->setObjectName(QString::fromUtf8("collegeAmountLable_4"));
        collegeAmountLable_4->setGeometry(QRect(510, 210, 141, 31));
        collegeAmountLable_4->setStyleSheet(QString::fromUtf8("font: 20pt \"Lao Sangam MN\";"));
        CollegePathBrowserASU = new QTextBrowser(tab_4);
        CollegePathBrowserASU->setObjectName(QString::fromUtf8("CollegePathBrowserASU"));
        CollegePathBrowserASU->setGeometry(QRect(510, 240, 531, 321));
        CollegePathBrowserASU->setStyleSheet(QString::fromUtf8("font: 20pt \"Lao Sangam MN\";"));
        label_10 = new QLabel(tab_4);
        label_10->setObjectName(QString::fromUtf8("label_10"));
        label_10->setGeometry(QRect(10, 260, 411, 16));
        collegeAmountBox = new QSpinBox(tab_4);
        collegeAmountBox->setObjectName(QString::fromUtf8("collegeAmountBox"));
        collegeAmountBox->setGeometry(QRect(430, 261, 41, 21));
        tripInfoASUButton = new QPushButton(tab_4);
        tripInfoASUButton->setObjectName(QString::fromUtf8("tripInfoASUButton"));
        tripInfoASUButton->setGeometry(QRect(160, 360, 131, 32));
        tripInfoASUButton->setStyleSheet(QString::fromUtf8("background-color: rgb(243, 255, 228);"));
        startTourButton_2 = new QPushButton(tab_4);
        startTourButton_2->setObjectName(QString::fromUtf8("startTourButton_2"));
        startTourButton_2->setGeometry(QRect(170, 540, 113, 32));
        startTourButton_2->setStyleSheet(QString::fromUtf8("background-color: rgb(173, 238, 169);"));
        tabWidget->addTab(tab_4, QString());
        tab_2 = new QWidget();
        tab_2->setObjectName(QString::fromUtf8("tab_2"));
        label_5 = new QLabel(tab_2);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setGeometry(QRect(380, 10, 321, 41));
        label_5->setStyleSheet(QString::fromUtf8("font: 30pt \"Lao Sangam MN\";"));
        comboBox = new QComboBox(tab_2);
        comboBox->addItem(QString());
        comboBox->setObjectName(QString::fromUtf8("comboBox"));
        comboBox->setGeometry(QRect(160, 120, 131, 32));
        label_6 = new QLabel(tab_2);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        label_6->setGeometry(QRect(30, 80, 151, 16));
        label_7 = new QLabel(tab_2);
        label_7->setObjectName(QString::fromUtf8("label_7"));
        label_7->setGeometry(QRect(30, 170, 131, 16));
        tripInformationButton = new QPushButton(tab_2);
        tripInformationButton->setObjectName(QString::fromUtf8("tripInformationButton"));
        tripInformationButton->setGeometry(QRect(150, 570, 131, 32));
        tripInformationButton->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 254, 217);\n"
"border-color: rgb(0, 0, 0);"));
        distanceLable = new QLabel(tab_2);
        distanceLable->setObjectName(QString::fromUtf8("distanceLable"));
        distanceLable->setGeometry(QRect(510, 80, 531, 16));
        distanceLable->setStyleSheet(QString::fromUtf8("font: 20pt \"Lao Sangam MN\";"));
        collegeAmountLable = new QLabel(tab_2);
        collegeAmountLable->setObjectName(QString::fromUtf8("collegeAmountLable"));
        collegeAmountLable->setGeometry(QRect(510, 130, 481, 31));
        collegeAmountLable->setStyleSheet(QString::fromUtf8("font: 20pt \"Lao Sangam MN\";"));
        comboBox2 = new QComboBox(tab_2);
        comboBox2->addItem(QString());
        comboBox2->setObjectName(QString::fromUtf8("comboBox2"));
        comboBox2->setGeometry(QRect(80, 210, 131, 32));
        comboBox3 = new QComboBox(tab_2);
        comboBox3->addItem(QString());
        comboBox3->setObjectName(QString::fromUtf8("comboBox3"));
        comboBox3->setGeometry(QRect(270, 210, 131, 32));
        comboBox4 = new QComboBox(tab_2);
        comboBox4->addItem(QString());
        comboBox4->setObjectName(QString::fromUtf8("comboBox4"));
        comboBox4->setGeometry(QRect(80, 270, 131, 32));
        comboBox5 = new QComboBox(tab_2);
        comboBox5->addItem(QString());
        comboBox5->setObjectName(QString::fromUtf8("comboBox5"));
        comboBox5->setGeometry(QRect(270, 270, 131, 32));
        comboBox6 = new QComboBox(tab_2);
        comboBox6->addItem(QString());
        comboBox6->setObjectName(QString::fromUtf8("comboBox6"));
        comboBox6->setGeometry(QRect(270, 330, 131, 32));
        comboBox7 = new QComboBox(tab_2);
        comboBox7->addItem(QString());
        comboBox7->setObjectName(QString::fromUtf8("comboBox7"));
        comboBox7->setGeometry(QRect(80, 330, 131, 32));
        comboBox8 = new QComboBox(tab_2);
        comboBox8->addItem(QString());
        comboBox8->setObjectName(QString::fromUtf8("comboBox8"));
        comboBox8->setGeometry(QRect(270, 390, 131, 32));
        comboBox9 = new QComboBox(tab_2);
        comboBox9->addItem(QString());
        comboBox9->setObjectName(QString::fromUtf8("comboBox9"));
        comboBox9->setGeometry(QRect(80, 390, 131, 32));
        comboBox10 = new QComboBox(tab_2);
        comboBox10->addItem(QString());
        comboBox10->setObjectName(QString::fromUtf8("comboBox10"));
        comboBox10->setGeometry(QRect(270, 460, 131, 32));
        comboBox11 = new QComboBox(tab_2);
        comboBox11->addItem(QString());
        comboBox11->setObjectName(QString::fromUtf8("comboBox11"));
        comboBox11->setGeometry(QRect(80, 520, 131, 32));
        comboBox12 = new QComboBox(tab_2);
        comboBox12->addItem(QString());
        comboBox12->setObjectName(QString::fromUtf8("comboBox12"));
        comboBox12->setGeometry(QRect(80, 460, 131, 32));
        checkBox2 = new QCheckBox(tab_2);
        checkBox2->setObjectName(QString::fromUtf8("checkBox2"));
        checkBox2->setGeometry(QRect(40, 210, 86, 20));
        checkBox3 = new QCheckBox(tab_2);
        checkBox3->setObjectName(QString::fromUtf8("checkBox3"));
        checkBox3->setGeometry(QRect(240, 210, 86, 20));
        checkBox5 = new QCheckBox(tab_2);
        checkBox5->setObjectName(QString::fromUtf8("checkBox5"));
        checkBox5->setGeometry(QRect(240, 270, 86, 20));
        checkBox4 = new QCheckBox(tab_2);
        checkBox4->setObjectName(QString::fromUtf8("checkBox4"));
        checkBox4->setGeometry(QRect(40, 270, 86, 20));
        checkBox6 = new QCheckBox(tab_2);
        checkBox6->setObjectName(QString::fromUtf8("checkBox6"));
        checkBox6->setGeometry(QRect(240, 330, 86, 20));
        checkBox7 = new QCheckBox(tab_2);
        checkBox7->setObjectName(QString::fromUtf8("checkBox7"));
        checkBox7->setGeometry(QRect(40, 330, 86, 20));
        checkBox9 = new QCheckBox(tab_2);
        checkBox9->setObjectName(QString::fromUtf8("checkBox9"));
        checkBox9->setGeometry(QRect(40, 390, 86, 20));
        checkBox8 = new QCheckBox(tab_2);
        checkBox8->setObjectName(QString::fromUtf8("checkBox8"));
        checkBox8->setGeometry(QRect(240, 390, 86, 20));
        checkBox12 = new QCheckBox(tab_2);
        checkBox12->setObjectName(QString::fromUtf8("checkBox12"));
        checkBox12->setGeometry(QRect(40, 460, 86, 20));
        checkBox10 = new QCheckBox(tab_2);
        checkBox10->setObjectName(QString::fromUtf8("checkBox10"));
        checkBox10->setGeometry(QRect(240, 460, 86, 20));
        checkBox11 = new QCheckBox(tab_2);
        checkBox11->setObjectName(QString::fromUtf8("checkBox11"));
        checkBox11->setGeometry(QRect(40, 520, 86, 20));
        collegeAmountLable_2 = new QLabel(tab_2);
        collegeAmountLable_2->setObjectName(QString::fromUtf8("collegeAmountLable_2"));
        collegeAmountLable_2->setGeometry(QRect(510, 190, 141, 31));
        collegeAmountLable_2->setStyleSheet(QString::fromUtf8("font: 20pt \"Lao Sangam MN\";"));
        CollegePathBrowser = new QTextBrowser(tab_2);
        CollegePathBrowser->setObjectName(QString::fromUtf8("CollegePathBrowser"));
        CollegePathBrowser->setGeometry(QRect(510, 220, 531, 321));
        CollegePathBrowser->setStyleSheet(QString::fromUtf8("font: 20pt \"Lao Sangam MN\";"));
        checkBox13 = new QCheckBox(tab_2);
        checkBox13->setObjectName(QString::fromUtf8("checkBox13"));
        checkBox13->setGeometry(QRect(240, 520, 86, 20));
        comboBox13 = new QComboBox(tab_2);
        comboBox13->addItem(QString());
        comboBox13->setObjectName(QString::fromUtf8("comboBox13"));
        comboBox13->setGeometry(QRect(270, 520, 131, 32));
        startTourButton = new QPushButton(tab_2);
        startTourButton->setObjectName(QString::fromUtf8("startTourButton"));
        startTourButton->setGeometry(QRect(850, 560, 113, 32));
        startTourButton->setStyleSheet(QString::fromUtf8("background-color: rgb(173, 238, 169);"));
        tabWidget->addTab(tab_2, QString());
        tab_6 = new QWidget();
        tab_6->setObjectName(QString::fromUtf8("tab_6"));
        distanceLable_4 = new QLabel(tab_6);
        distanceLable_4->setObjectName(QString::fromUtf8("distanceLable_4"));
        distanceLable_4->setGeometry(QRect(100, 100, 531, 16));
        distanceLable_4->setStyleSheet(QString::fromUtf8("font: 20pt \"Lao Sangam MN\";"));
        CollegePathBrowserSaddleback = new QTextBrowser(tab_6);
        CollegePathBrowserSaddleback->setObjectName(QString::fromUtf8("CollegePathBrowserSaddleback"));
        CollegePathBrowserSaddleback->setGeometry(QRect(100, 240, 541, 341));
        CollegePathBrowserSaddleback->setStyleSheet(QString::fromUtf8("font: 20pt \"Lao Sangam MN\";"));
        collegeAmountLableSaddleback = new QLabel(tab_6);
        collegeAmountLableSaddleback->setObjectName(QString::fromUtf8("collegeAmountLableSaddleback"));
        collegeAmountLableSaddleback->setGeometry(QRect(100, 150, 481, 31));
        collegeAmountLableSaddleback->setStyleSheet(QString::fromUtf8("font: 20pt \"Lao Sangam MN\";"));
        collegeAmountLable_6 = new QLabel(tab_6);
        collegeAmountLable_6->setObjectName(QString::fromUtf8("collegeAmountLable_6"));
        collegeAmountLable_6->setGeometry(QRect(100, 210, 141, 31));
        collegeAmountLable_6->setStyleSheet(QString::fromUtf8("font: 20pt \"Lao Sangam MN\";"));
        label_13 = new QLabel(tab_6);
        label_13->setObjectName(QString::fromUtf8("label_13"));
        label_13->setGeometry(QRect(250, 20, 561, 41));
        label_13->setStyleSheet(QString::fromUtf8("font: 30pt \"Lao Sangam MN\";"));
        startTourButton_3 = new QPushButton(tab_6);
        startTourButton_3->setObjectName(QString::fromUtf8("startTourButton_3"));
        startTourButton_3->setGeometry(QRect(880, 550, 113, 32));
        startTourButton_3->setStyleSheet(QString::fromUtf8("background-color: rgb(173, 238, 169);"));
        tabWidget->addTab(tab_6, QString());
        pushButton = new QPushButton(StudentConsole);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(940, 40, 113, 32));
        pushButton->setStyleSheet(QString::fromUtf8("background-color: rgb(254, 177, 172);"));

        retranslateUi(StudentConsole);

        tabWidget->setCurrentIndex(5);


        QMetaObject::connectSlotsByName(StudentConsole);
    } // setupUi

    void retranslateUi(QDialog *StudentConsole)
    {
        StudentConsole->setWindowTitle(QApplication::translate("StudentConsole", "Dialog", nullptr));
        label->setText(QApplication::translate("StudentConsole", "Welcome!", nullptr));
        label_2->setText(QApplication::translate("StudentConsole", "Check out our colleges and souvenirs!", nullptr));
        label_3->setText(QApplication::translate("StudentConsole", "College List", nullptr));
        label_4->setText(QApplication::translate("StudentConsole", "Souvenior Table", nullptr));
        viewSouvButton->setText(QApplication::translate("StudentConsole", "View Souvenirs", nullptr));
        label_12->setText(QApplication::translate("StudentConsole", "Pick a college:", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(tab), QApplication::translate("StudentConsole", "Student Home", nullptr));
        label_8->setText(QApplication::translate("StudentConsole", "Distances From Saddleback College", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(tab_3), QApplication::translate("StudentConsole", "Distances", nullptr));
        distanceLable_3->setText(QApplication::translate("StudentConsole", "Total Distance Of Shortest Path (Miles):", nullptr));
        collegeAmountLableUCI->setText(QApplication::translate("StudentConsole", "Number of Colleges: ", nullptr));
        collegeAmountLable_5->setText(QApplication::translate("StudentConsole", "College Path:", nullptr));
        label_11->setText(QApplication::translate("StudentConsole", "Planning A Trip Starting From UCI", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(tab_5), QApplication::translate("StudentConsole", "Visiting Initial Colleges From UCI", nullptr));
        label_9->setText(QApplication::translate("StudentConsole", "Planning A Trip Starting From ASU!", nullptr));
        collegeAmountLableASU->setText(QApplication::translate("StudentConsole", "Number of Colleges: ", nullptr));
        distanceLable_2->setText(QApplication::translate("StudentConsole", "Total Distance Of Shortest Path (Miles):", nullptr));
        collegeAmountLable_4->setText(QApplication::translate("StudentConsole", "College Path:", nullptr));
        label_10->setText(QApplication::translate("StudentConsole", "Enter the Amount of Colleges You Wish To visit Starting From ASU:", nullptr));
        tripInfoASUButton->setText(QApplication::translate("StudentConsole", "Display Trip Info", nullptr));
        startTourButton_2->setText(QApplication::translate("StudentConsole", "Start Tour!", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(tab_4), QApplication::translate("StudentConsole", "Plan Trip Starting From ASU", nullptr));
        label_5->setText(QApplication::translate("StudentConsole", "Plan A Custom Trip!", nullptr));
        comboBox->setItemText(0, QApplication::translate("StudentConsole", "Select College", nullptr));

        label_6->setText(QApplication::translate("StudentConsole", "Pick A Starting College:", nullptr));
        label_7->setText(QApplication::translate("StudentConsole", "Pick Other Colleges:", nullptr));
        tripInformationButton->setText(QApplication::translate("StudentConsole", "Trip Information", nullptr));
        distanceLable->setText(QApplication::translate("StudentConsole", "Total Distance Of Shortest Path (Miles):", nullptr));
        collegeAmountLable->setText(QApplication::translate("StudentConsole", "Number of Colleges: ", nullptr));
        comboBox2->setItemText(0, QApplication::translate("StudentConsole", "Select College", nullptr));

        comboBox3->setItemText(0, QApplication::translate("StudentConsole", "Select College", nullptr));

        comboBox4->setItemText(0, QApplication::translate("StudentConsole", "Select College", nullptr));

        comboBox5->setItemText(0, QApplication::translate("StudentConsole", "Select College", nullptr));

        comboBox6->setItemText(0, QApplication::translate("StudentConsole", "Select College", nullptr));

        comboBox7->setItemText(0, QApplication::translate("StudentConsole", "Select College", nullptr));

        comboBox8->setItemText(0, QApplication::translate("StudentConsole", "Select College", nullptr));

        comboBox9->setItemText(0, QApplication::translate("StudentConsole", "Select College", nullptr));

        comboBox10->setItemText(0, QApplication::translate("StudentConsole", "Select College", nullptr));

        comboBox11->setItemText(0, QApplication::translate("StudentConsole", "Select College", nullptr));

        comboBox12->setItemText(0, QApplication::translate("StudentConsole", "Select College", nullptr));

        checkBox2->setText(QString());
        checkBox3->setText(QString());
        checkBox5->setText(QString());
        checkBox4->setText(QString());
        checkBox6->setText(QString());
        checkBox7->setText(QString());
        checkBox9->setText(QString());
        checkBox8->setText(QString());
        checkBox12->setText(QString());
        checkBox10->setText(QString());
        checkBox11->setText(QString());
        collegeAmountLable_2->setText(QApplication::translate("StudentConsole", "College Path:", nullptr));
        checkBox13->setText(QString());
        comboBox13->setItemText(0, QApplication::translate("StudentConsole", "Select College", nullptr));

        startTourButton->setText(QApplication::translate("StudentConsole", "Start Tour!", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(tab_2), QApplication::translate("StudentConsole", "Plan Custom Trip", nullptr));
        distanceLable_4->setText(QApplication::translate("StudentConsole", "Total Distance Of Shortest Path (Miles):", nullptr));
        collegeAmountLableSaddleback->setText(QApplication::translate("StudentConsole", "Number of Colleges: ", nullptr));
        collegeAmountLable_6->setText(QApplication::translate("StudentConsole", "College Path:", nullptr));
        label_13->setText(QApplication::translate("StudentConsole", "Planning A Trip Starting From Saddleback", nullptr));
        startTourButton_3->setText(QApplication::translate("StudentConsole", "Start Tour!", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(tab_6), QApplication::translate("StudentConsole", "Plan Trip From Saddleback", nullptr));
        pushButton->setText(QApplication::translate("StudentConsole", "Home", nullptr));
    } // retranslateUi

};

namespace Ui {
    class StudentConsole: public Ui_StudentConsole {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_STUDENTCONSOLE_H
