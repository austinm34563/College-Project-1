#include "adminpage.h"
#include "ui_adminpage.h"
#include "introductorypage.h"
#include <QMessageBox>
#include <QDebug>


AdminPage::AdminPage(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::AdminPage)
{
    ui->setupUi(this);
}

AdminPage::~AdminPage()
{
    delete ui;
}

void AdminPage::on_addCollegeButton_clicked()
{
    QString collegeName = ui->CollegeName->text();

    if(canAddNew(collegeName)){

        connOpen();

        QSqlQuery qry;
        QSqlQuery newDistancesQry;

        qry.prepare("INSERT INTO CollegeList(Name) VALUES(:Name)");
        qry.bindValue(":Name", collegeName);
        if(qry.exec()){
            QMessageBox::information(this, tr("Message"), "College Added Successfully!");
            newDistancesQry.prepare("INSERT INTO Distances (Start, End, Distance) SELECT Start, Finish, Distance FROM NewDistances WHERE (Start = :Start AND Finish IN (SELECT Name FROM CollegeList)) OR (Finish = :Finish AND Start IN (SELECT Name FROM CollegeList))");
            newDistancesQry.bindValue(":Start", collegeName);
            newDistancesQry.bindValue(":Finish", collegeName);
            newDistancesQry.exec();
        }
        else {
            QMessageBox::critical(this, tr("Error"), "College already exists! Please Try Again.");
        }
        connClose();
    }
    else {
            QMessageBox::critical(this, tr("Error"), "Invalid Entry! Unable to add college.");
    }




}

void AdminPage::on_viewCollegeButton_clicked()
{
    //set up a Model pointer - Austin Murphy
    QSqlQueryModel * modal = new QSqlQueryModel();

    //open the database - Austin Murphy
    connOpen();
    QSqlQuery* qry = new QSqlQuery(myDatabase);

    //retreive the information from the database - Austin Murphy
    qry->prepare("SELECT * FROM CollegeList ORDER BY Name ASC");

    //execute the query and show the model in the Admin Only Console - Austin Murphy
    qry->exec();
    modal->setQuery(*qry);
    ui->dataTable->setModel(modal);

    //Close the connection - Austin Murphy
    connClose();
}

void AdminPage::on_viewDistButton_clicked()
{
    //set up a Model pointer - Austin Murphy
    QSqlQueryModel * modal = new QSqlQueryModel();

    //open the database - Austin Murphy
    connOpen();
    QSqlQuery* qry = new QSqlQuery(myDatabase);

    //retreive the information from the database - Austin Murphy
    qry->prepare("SELECT * FROM Distances ORDER BY Start ASC");

    //execute the query and show the model in the Admin Only Console - Austin Murphy
    qry->exec();
    modal->setQuery(*qry);
    ui->dataTable->setModel(modal);

    //Close the connection - Austin Murphy
    connClose();
}

void AdminPage::on_viewSouvButton_clicked()
{
    //set up a Model pointer - Austin Murphy
    QSqlQueryModel * modal = new QSqlQueryModel();

    //open the database - Austin Murphy
    connOpen();
    QSqlQuery* qry = new QSqlQuery(myDatabase);

    //retreive the information from the database - Austin Murphy
    qry->prepare("SELECT * FROM SouveniorList ORDER BY College ASC");

    //execute the query and show the model in the Admin Only Console - Austin Murphy
    qry->exec();
    modal->setQuery(*qry);
    ui->dataTable->setModel(modal);

    //Close the connection - Austin Murphy
    connClose();
}



void AdminPage::on_souvenirAddButton_clicked()
{
    QString collegeName, souvName, price;
    collegeName = ui->collegeSouveName->text();
    souvName = ui->souvenir->text();
    price = ui->price->text();

    if(collegeExist(collegeName)){

        connOpen();

        QSqlQuery distanceQry;

        distanceQry.prepare("INSERT INTO SouveniorList(College, SouvenirName, Price) VALUES(:colName, :souvName, :Price)");
        distanceQry.bindValue(":colName", collegeName);
        distanceQry.bindValue(":souvName", souvName);
        distanceQry.bindValue(":Price", price);
        distanceQry.exec();
        QMessageBox::information(this, tr("Message"), "Souvenir Added Succesfully!");
        connClose();
    }

    else{
        QMessageBox::critical(this, tr("Not Found"), "College Not Found! Please Try Again.");

    }

}

void AdminPage::on_deleteSouvButton_clicked()
{
    QString collegeName, souvName;

    collegeName = ui->collegeDelete->text();
    souvName = ui->souvDelete->text();

    if(collegeExist(collegeName)){
        connOpen();

        QSqlQuery deleteQry;

        deleteQry.prepare("DELETE FROM SouveniorList WHERE College = :College and SouvenirName = :souvName");
        deleteQry.bindValue(":College", collegeName);
        deleteQry.bindValue(":souvName", souvName);
        deleteQry.exec();
        QMessageBox::information(this, tr("Message"), "Souvenir Deleted Succesfully!");
        connClose();
    }
    else {
        QMessageBox::critical(this, tr("Not Found"), "College Not Found! Please Try Again.");

    }

}

void AdminPage::on_updatePriceButton_clicked()
{
    QString collegeName, souvName, price;
    collegeName = ui->collegeUpdate->text();
    souvName = ui->souvenirUpdate->text();
    price = ui->priceUpdate->text();

    if(collegeExist(collegeName)){

        connOpen();

        QSqlQuery priceQry;

        priceQry.prepare("UPDATE SouveniorList SET Price = :Price WHERE College = :colName and SouvenirName = :souvName");
        priceQry.bindValue(":colName", collegeName);
        priceQry.bindValue(":souvName", souvName);
        priceQry.bindValue(":Price", price);
        priceQry.exec();
        QMessageBox::information(this, tr("Message"), "Souvenir Price Updated Succesfully!");
        connClose();
    }

    else{
        QMessageBox::critical(this, tr("Not Found"), "College Not Found! Please Try Again.");

    }
}

void AdminPage::on_homeButton_clicked()
{
    IntroductoryPage *intro = new IntroductoryPage(this);
    intro->show();
    hide();
}
