#include "studentconsole.h"
#include "ui_studentconsole.h"
#include "adminpage.h"
#include "introductorypage.h"
#include <QStandardItemModel>
#include <QVector>
#include <QString>
#include <QDebug>
#include <QMessageBox>

StudentConsole::StudentConsole(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::StudentConsole)
{
    ui->setupUi(this);
    AdminPage admin;
    //set up a Model pointer - Austin Murphy
    QSqlQueryModel * modal = new QSqlQueryModel();
    QSqlQueryModel * modal2 = new QSqlQueryModel();
    QSqlQueryModel * modal3 = new QSqlQueryModel();

    //open the database - Austin Murphy
    admin.connOpen();
    QSqlQuery *qry = new QSqlQuery(admin.myDatabase);
    QSqlQuery *qrySouv = new QSqlQuery(admin.myDatabase);
    QSqlQuery *distQry = new QSqlQuery(admin.myDatabase);

    //retreive the information from the database - Austin Murphy
    qry->prepare("SELECT * FROM CollegeList ORDER BY Name ASC");
    qrySouv->prepare("SELECT * FROM SouveniorList ORDER BY College ASC");
    distQry->prepare("SELECT * FROM Distances WHERE Start = :Start ORDER BY Start ASC");
    distQry->bindValue(":Start", "Saddleback College");

    //execute the query and show the model in the Admin Only Console - Austin Murphy
    qry->exec();
    modal->setQuery(*qry);
    ui->dataTable->setModel(modal);
    ui->comboBox->setModel(modal);
    ui->comboBox2->setModel(modal);
    ui->comboBox3->setModel(modal);
    ui->comboBox4->setModel(modal);
    ui->comboBox5->setModel(modal);
    ui->comboBox6->setModel(modal);
    ui->comboBox7->setModel(modal);
    ui->comboBox8->setModel(modal);
    ui->comboBox9->setModel(modal);
    ui->comboBox10->setModel(modal);
    ui->comboBox11->setModel(modal);
    ui->comboBox12->setModel(modal);
    ui->comboBox13->setModel(modal);
    ui->collegeComboBox->setModel(modal);

    //exectue qry and show it in table
    qrySouv->exec();
    modal2->setQuery(*qrySouv);

    //exectue dist qry and show it in table
    distQry->exec();
    modal3->setQuery(*distQry);
    ui->distancesTable->setModel(modal3);

    //Close the connection - Austin Murphy
    admin.connClose();

    //get the amount of colleges that are in the collge list DB
    int rows = 0;
    AdminPage adminAmount;
    adminAmount.connOpen();
    QSqlQuery qryAmount;
    qryAmount.prepare("SELECT COUNT(*) FROM CollegeList");
    qryAmount.exec();

    //get the value of the shortest distance and place it into distancePlaceHolder
    while(qryAmount.next()){
        rows = qryAmount.value(0).toInt();
    }

    //close the DB File
    adminAmount.connClose();

    //CLOSEST TO UCI
    tourInfo infoUCI;
    QString collegePathUCI;
    infoUCI = infoFromCollegeAmt("University of California, Irvine (UCI)", rows);
    for(int i = 0; i < infoUCI.colleges.size(); i++){
        collegePathUCI = collegePathUCI + QString::number(i + 1) + ". " + infoUCI.colleges.at(i) + "\n";
    }

    ui->distanceLable_3->setText("Total Distance Of Shortest Path (Miles): " + QString::number(infoUCI.distance));

    ui->collegeAmountLableUCI->setText("Number of Colleges:  " + QString::number(infoUCI.colleges.size()));
    ui->CollegePathBrowserUCI->setText(collegePathUCI);

    //CLOSEST TO Saddleback
    tourInfo infoSaddleback;
    QString collegePathSaddleback;
    infoSaddleback = infoFromCollegeAmt("Saddleback College", rows);
    for(int i = 0; i < infoSaddleback.colleges.size(); i++){
        collegePathSaddleback = collegePathSaddleback + QString::number(i + 1) + ". " + infoSaddleback.colleges.at(i) + "\n";
    }

    ui->distanceLable_4->setText("Total Distance Of Shortest Path (Miles): " + QString::number(infoSaddleback.distance));

    ui->collegeAmountLableSaddleback->setText("Number of Colleges:  " + QString::number(infoSaddleback.colleges.size()));
    ui->CollegePathBrowserSaddleback->setText(collegePathUCI);



}

StudentConsole::~StudentConsole()
{
    delete ui;
}


void StudentConsole::on_pushButton_clicked()
{
    IntroductoryPage *intro = new IntroductoryPage(this);

    intro->show();
    hide();
}



void StudentConsole::on_tripInformationButton_clicked()
{
    QVector<QString> collegeTour;
    QString startingCollege = ui->comboBox->currentText();
    tourInfo information;
    collegeTour.append(startingCollege);

    if(ui->checkBox2->isChecked()){
        collegeTour.append(ui->comboBox2->currentText());
    }
    if(ui->checkBox3->isChecked()){
        collegeTour.append(ui->comboBox3->currentText());
    }
    if(ui->checkBox4->isChecked()){
        collegeTour.append(ui->comboBox4->currentText());
    }
    if(ui->checkBox5->isChecked()){
        collegeTour.append(ui->comboBox5->currentText());
    }
    if(ui->checkBox6->isChecked()){
        collegeTour.append(ui->comboBox6->currentText());
    }
    if(ui->checkBox7->isChecked()){
        collegeTour.append(ui->comboBox7->currentText());
    }
    if(ui->checkBox8->isChecked()){
        collegeTour.append(ui->comboBox8->currentText());
    }
    if(ui->checkBox9->isChecked()){
        collegeTour.append(ui->comboBox9->currentText());
    }
    if(ui->checkBox10->isChecked()){
        collegeTour.append(ui->comboBox10->currentText());
    }
    if(ui->checkBox11->isChecked()){
        collegeTour.append(ui->comboBox11->currentText());
    }
    if(ui->checkBox12->isChecked()){
        collegeTour.append(ui->comboBox12->currentText());
    }
    if(ui->checkBox13->isChecked()){
        collegeTour.append(ui->comboBox13->currentText());
    }

    if(multipleCollegeCheck(collegeTour)){
        QMessageBox::critical(this, tr("Error"), "Error! College entered more than once! Try Again");
    }
    else{
        information = getInfo(collegeTour);

        QString collegePath;

        for(int i = 0; i < information.colleges.size(); i++){
            collegePath = collegePath + QString::number(i + 1) + ". " + information.colleges.at(i) + "\n";
        }

        ui->distanceLable->setText("Total Distance Of Shortest Path (Miles): " + QString::number(information.distance));

        ui->collegeAmountLable->setText("Number of Colleges:  " + QString::number(information.colleges.size()));

        ui->CollegePathBrowser->setText(collegePath);
    }
}

void StudentConsole::on_tripInfoASUButton_clicked()
{
    int collegeAmount = ui->collegeAmountBox->value();

    if(correctCollegeAmount(collegeAmount)){
        tourInfo touring = infoFromCollegeAmt("Arizona State University",collegeAmount);

        QString collegePath;

        for(int i = 0; i < touring.colleges.size(); i++){
            collegePath = collegePath + QString::number(i + 1) + ". " + touring.colleges.at(i) + "\n";
        }

        ui->distanceLable_2->setText("Total Distance Of Shortest Path (Miles): " + QString::number(touring.distance));

        ui->collegeAmountLableASU->setText("Number of Colleges:  " + QString::number(touring.colleges.size()));

        ui->CollegePathBrowserASU->setText(collegePath);
    }



}

void StudentConsole::on_viewSouvButton_clicked()
{
    QString college = ui->collegeComboBox->currentText();
    QSqlQueryModel * modal = new QSqlQueryModel();

    AdminPage admin;

    admin.connOpen();

    QSqlQuery *qry = new QSqlQuery(admin.myDatabase);

    qry->prepare("SELECT * FROM SouveniorList WHERE College = :College ORDER BY College ASC ");
    qry->bindValue(":College", college);
    qry->exec();
    modal->setQuery(*qry);

    ui->souvDataTable->setModel(modal);
}




// ----- Buttons that start the college Tour feature ----- //

void StudentConsole::on_startTourButton_clicked()
{
    QVector<QString> collegeNames;
    tourPtr = new tour(collegeNames, this);
    tourPtr->show();
}

void StudentConsole::on_startTourButton_2_clicked()
{
    QVector<QString> collegeNames;
    tourPtr = new tour(collegeNames, this);
    tourPtr->show();
}

void StudentConsole::on_startTourButton_3_clicked()
{
    QVector<QString> collegeNames;
    tourPtr = new tour(collegeNames, this);
    tourPtr->show();
}
