#ifndef ADMINPAGE_H
#define ADMINPAGE_H

#include <QDialog>
#include <QtSql>

namespace Ui {
class AdminPage;
}

class AdminPage : public QDialog
{
    Q_OBJECT

public:
    explicit AdminPage(QWidget *parent = nullptr);
    ~AdminPage();

    QSqlDatabase myDatabase;

    void connClose(){
        myDatabase.close();
        myDatabase.removeDatabase(QSqlDatabase::defaultConnection);
    }

    bool connOpen(){
        myDatabase = QSqlDatabase::addDatabase("QSQLITE");
        myDatabase.setDatabaseName("/Users/austinm/CollegeDatabase.db");

        if(!myDatabase.open()){
            qDebug()<<("Database Status: Not Connected");
            return false;
        }
        else{
            qDebug()<<("Database Status: Connected");
            return true;
        }
    }

private slots:
    void on_addCollegeButton_clicked();

    void on_viewCollegeButton_clicked();

    void on_viewDistButton_clicked();

    void on_viewSouvButton_clicked();

    void on_souvenirAddButton_clicked();

    void on_deleteSouvButton_clicked();

    void on_updatePriceButton_clicked();

    void on_homeButton_clicked();

private:
    Ui::AdminPage *ui;

    bool canAddNew(QString collegeName){
        connOpen();
        QSqlQuery qryCheck;
        qryCheck.prepare("SELECT * FROM NewCollegeList WHERE NewName = :Name");
        qryCheck.bindValue(":Name", collegeName);
        qryCheck.exec();
        int count = 0;
        while(qryCheck.next()){
            count++;
        }
        connClose();
        return (count == 1);
    }

    bool collegeExist(QString collegeName){
        connOpen();
        QSqlQuery qryCheck;
        qryCheck.prepare("SELECT * FROM CollegeList WHERE Name = :Name");
        qryCheck.bindValue(":Name", collegeName);
        qryCheck.exec();
        int count = 0;
        while(qryCheck.next()){
            count++;
        }
        connClose();
        return (count == 1);
    }

};

#endif // ADMINPAGE_H
