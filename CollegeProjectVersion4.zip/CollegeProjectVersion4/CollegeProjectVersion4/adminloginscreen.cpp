#include "adminloginscreen.h"
#include "ui_adminloginscreen.h"
#include <QMessageBox>

AdminLoginScreen::AdminLoginScreen(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::AdminLoginScreen)
{
    ui->setupUi(this);
}

AdminLoginScreen::~AdminLoginScreen()
{
    delete ui;
}

void AdminLoginScreen::on_loginButton_clicked()
{
    if(ui->usernameLine->text() == "Admin" && ui->passwordLine->text() == "123"){
        adminPagePtr = new AdminPage(this);
        adminPagePtr->show();
        hide();
    }
    else {
        QMessageBox::critical(this, tr("WARNING"), tr("Invalid Username or Password"));
    }


}
