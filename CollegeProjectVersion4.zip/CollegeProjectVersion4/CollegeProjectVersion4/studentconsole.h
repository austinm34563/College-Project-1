#ifndef STUDENTCONSOLE_H
#define STUDENTCONSOLE_H

#include <QDialog>
#include <QVector>
#include <QList>
#include <QVariantList>
#include "adminpage.h"
#include <QMessageBox>
#include "tour.h"

namespace Ui {
class StudentConsole;
}

class StudentConsole : public QDialog
{
    Q_OBJECT

public:
    explicit StudentConsole(QWidget *parent = nullptr);
    ~StudentConsole();


private slots:

    void on_pushButton_clicked();

    void on_tripInformationButton_clicked();


    void on_tripInfoASUButton_clicked();

    void on_viewSouvButton_clicked();

    void on_startTourButton_clicked();

    void on_startTourButton_2_clicked();

    void on_startTourButton_3_clicked();

private:
    Ui::StudentConsole *ui;
    tour * tourPtr;

    struct tourInfo{
        double distance;
        QVector<QString> colleges;
    };

    QString listIntoString(QList<QString> list){
        QString listString = "(";
        for(int i = 0; i < list.size(); i++){
            if(i == list.size()-1)
                listString = listString + "'" + list.at(i) + "'";
            else
                listString = listString + "'"+ list.at(i) + "', ";
        }

        listString = listString + ")";

        return listString;
    }


    tourInfo getInfo(QVector<QString> college){

        //implementing admin object to gain access to College DB
        AdminPage admin;

        //struct object that takes control of the college list as a vector and total Distance traveled
        tourInfo touring;

        //qString to hold which college should be removed from the initial list
        QString collegeRemove;

        //LIST Datastructure that holds the possible colleges that the "previous" college can go to
        QList<QString> list;

        //add the first college to the touring vector in the tourInfo Object
        touring.colleges.append(college.front());

        //append the rest of the items into the list
        for(int i = 1; i < college.size(); i++){
            list.append(college.at(i));
        }

        //define the distance to be 0
        double distance = 0;

        //define the Placeholder of the distance to be 0 as well
        double distancePlaceHolder = 0;

        //access the rest of the colleges and put them in the respective order
        for(int j = 0; j < college.size() - 1; j++){

            //print the list and which itteration the for loop is on to the console
            qDebug() << j;
            qDebug() << listIntoString(list);

            //open the database
            admin.connOpen();

            //define the two query's
            QSqlQuery qry;
            QSqlQuery getCollegeQry;

            //prepare a qry to select the min distance
            qry.prepare("SELECT MIN(Distance) FROM Distances WHERE Start = :Start AND End IN " + listIntoString(list));
            qry.bindValue(":Start", touring.colleges.at(j));

            //execute the qry
            qry.exec();

            //get the value of the shortest distance and place it into distancePlaceHolder
            while(qry.next()){
                distancePlaceHolder = qry.value(0).toDouble();
            }

            //increase the distance by the shortest distance
            distance += distancePlaceHolder;

            //prepare a qry to get the name of the college
            getCollegeQry.prepare("SELECT End FROM Distances WHERE Distance = :Distance AND Start = :Start");
            getCollegeQry.bindValue(":Start", touring.colleges.at(j));
            getCollegeQry.bindValue(":Distance", distancePlaceHolder);

            //execute the qry
            getCollegeQry.exec();

            //place the name into the college that is now going to be removed from the list of colleges that have not been added yet
            while(getCollegeQry.next()){
                collegeRemove = getCollegeQry.value(0).toString();
            }

            //append the college into the touring info vector
            touring.colleges.append(collegeRemove);

            //close college DB
            admin.connClose();

            //remove the college that has been added to the vector
            list.removeAt(list.indexOf(collegeRemove));
        }

        //set the distance of the tour into the touringInfo struct Object
        touring.distance = distance;
        qDebug() << touring.distance;

        //return the object
        return touring;
    }

    bool multipleCollegeCheck(QVector<QString> college){
        bool repeat = false;
        for(int i = 0; i < college.size(); i++){
            for(int j = i + 1; j < college.size(); j++){
                if(college.at(i) == college.at(j)){
                    repeat = true;
                    break;
                }
            }
        }

        return repeat;
    }

    tourInfo infoFromCollegeAmt(QString College, int amount){

        //implementing admin object to gain access to College DB
        AdminPage admin;

        //struct object that takes control of the college list as a vector and total Distance traveled
        tourInfo touring;

        //qString to hold which college should be removed from the initial list
        QString collegeAdd;

        //add the first college to the touring vector in the tourInfo Object
        touring.colleges.append(College);


        double distancePlaceHolder = 0;
        double distance = 0;

        for(int i = 0; i < amount-1; i++){
            admin.connOpen();

            QSqlQuery qry;
            QSqlQuery getCollegeQry;


            //prepare a qry to select the min distance
            qry.prepare("SELECT MIN(Distance) FROM Distances WHERE Start = :Start AND End NOT IN " + vectorToString(touring.colleges));
            qry.bindValue(":Start", touring.colleges.at(i));

            //execute the qry
            qry.exec();

            //get the value of the shortest distance and place it into distancePlaceHolder
            while(qry.next()){
                distancePlaceHolder = qry.value(0).toDouble();
            }

            distance += distancePlaceHolder;

            //prepare a qry to get the name of the college
            getCollegeQry.prepare("SELECT End FROM Distances WHERE Distance = :Distance AND Start = :Start");
            getCollegeQry.bindValue(":Start", touring.colleges.at(i));
            getCollegeQry.bindValue(":Distance", distancePlaceHolder);

            //execute the qry
            getCollegeQry.exec();

            //place the name into the college that is now going to be removed from the list of colleges that have not been added yet
            while(getCollegeQry.next()){
                collegeAdd = getCollegeQry.value(0).toString();
            }

            //append the college into the touring info vector
            touring.colleges.append(collegeAdd);

            admin.connClose();
        }

        touring.distance = distance;

        return touring;

    }

    QString vectorToString(QVector<QString> vector){
        QString listString = "(";
        for(int i = 0; i < vector.size() - 1; i++){
            if(i == vector.size()-2)
                listString = listString + "'" + vector.at(i) + "'";
            else
                listString = listString + "'"+ vector.at(i) + "', ";
        }

        listString = listString + ")";

        return listString;

    }

    bool correctCollegeAmount(int collegeAmount){
        bool amountCheck = true;
        int rows = 0;
        AdminPage admin;
        admin.connOpen();
        QSqlQuery qry;
        qry.prepare("SELECT COUNT(*) FROM CollegeList");
        qry.exec();
        //get the value of the shortest distance and place it into distancePlaceHolder
        while(qry.next()){
            rows = qry.value(0).toInt();
        }
        qDebug() <<rows;

        if(collegeAmount <= 0){
            QMessageBox::critical(this, tr("Error"), "Error! Cannot enter 0 or below colleges.");
            amountCheck = false;
        }
        else if(collegeAmount > rows){
            QMessageBox::critical(this, tr("Error"), "Error! Too many Colleges Entered.");
            amountCheck = false;
        }
        admin.connClose();
        return amountCheck;


    }
};



#endif // STUDENTCONSOLE_H
