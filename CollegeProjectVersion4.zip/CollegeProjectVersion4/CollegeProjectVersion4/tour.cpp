#include "tour.h"
#include "ui_tour.h"

// ----- Default constructor for the College Tour feature ----- //
tour::tour(QVector<QString> collegeNames, QWidget *parent) :
    QDialog(parent),
    ui(new Ui::tour)
{
    ui->setupUi(this);

    // Test Data to fill in a vector of strings (can delete later when using the real vector from the database).
    collegeNames.push_front("Saddleback");
    collegeNames.push_front("UCLA");
    collegeNames.push_front("Fullerton");
    collegeNames.push_front("UCI");
    collegeNames.push_front("IVC");
    collegeNames.push_front("Long Beach");
    collegeNames.push_front("Poly");
    collegeNames.push_front("Santa Barbara");
    collegeNames.push_front("San Diego");
    collegeNames.push_front("Davis");
    collegeNames.push_front("USC");
    qDebug() << collegeNames.size();


    // All 13 widgets for a potential size of 13 colleges in the vector will be created upon starting the Tour feature,
    // however they will initially all be blank. The size of the college vector will determine how many widgets are
    // filled with data.
    //
    // collegeName_i: Stores the corresponding college name string in the specified vector's index to the corresponding ui label (collegeName_i).
    //
    // offOn_i: Determines whether a "next college" button on each individual widget is needed. For instance if there are 4 colleges being toured,
    //          a next button wouldn't be needed on the fourth (and final) college, because that would be the end. So in this instance,
    //          offOn_3 (taking into account that 'i' is 3 instead of 4 because the next button is only needed on the previous widget before the last)
    //          is set to 1 (indicating a next button will show versus 0, which would indicate a next button would remain unseen).
    //
    for (int i = 0; i < collegeNames.size(); i++)
    {
        if (i == 0)
        {
            ui->collegeName_0->setText(collegeNames[0]);
        }
        if (i == 1)
        {
           ui->collegeName_1->setText(collegeNames[1]);
           ui->offOn_0->setCurrentIndex(1);
        }
        if (i == 2)
        {
            ui->collegeName_2->setText(collegeNames[2]);
            ui->offOn_1->setCurrentIndex(1);
        }
        if (i == 3)
        {
            ui->collegeName_3->setText(collegeNames[3]);
            ui->offOn_2->setCurrentIndex(1);
        }
        if (i == 4)
        {
            ui->collegeName_4->setText(collegeNames[4]);
            ui->offOn_3->setCurrentIndex(1);
        }
        if (i == 5)
        {
            ui->collegeName_5->setText(collegeNames[5]);
            ui->offOn_4->setCurrentIndex(1);
        }
        if (i == 6)
        {
            ui->collegeName_6->setText(collegeNames[6]);
            ui->offOn_5->setCurrentIndex(1);
        }
        if (i == 7)
        {
            ui->collegeName_7->setText(collegeNames[7]);
            ui->offOn_6->setCurrentIndex(1);
        }
        if (i == 8)
        {
            ui->collegeName_8->setText(collegeNames[8]);
            ui->offOn_7->setCurrentIndex(1);
        }
        if (i == 9)
        {
            ui->collegeName_9->setText(collegeNames[9]);
            ui->offOn_8->setCurrentIndex(1);
        }
        if (i == 10)
        {
            ui->collegeName_10->setText(collegeNames[10]);
            ui->offOn_9->setCurrentIndex(1);
        }
        if (i == 11)
        {
            ui->collegeName_11->setText(collegeNames[11]);
            ui->offOn_10->setCurrentIndex(1);
        }
        if (i == 12)
        {
            ui->collegeName_12->setText(collegeNames[12]);
            ui->offOn_11->setCurrentIndex(1);
        }
    }

    // If the college name vector is void, a message will display.
    if (collegeNames.size() == 0)
    {
        ui->label_0->deleteLater();
        ui->souvenirs_0->deleteLater();
        ui->voidOffOn->setCurrentIndex(1);
        ui->voidMessage->setText("No colleges have been selected to tour.");
    }


}

// Old test (can ignore)
tour::tour(QVector<QString> collegeNames)
{
    qDebug() << "Test.";
}

// Destructor
tour::~tour()
{
    delete ui;
}

// A button to exit the Tour feature and return to the main student interface
void tour::on_returnButton_clicked()
{
    this->close();
}




// ----- Previous and Next Buttons for each college widget ----- //

void tour::on_nextCollege_0_clicked()
{
    // Closes the tour ui window.
    ui->colleges->setCurrentIndex(1);
}

void tour::on_previousCollege_1_clicked()
{
    ui->colleges->setCurrentIndex(0);
}

void tour::on_nextCollege_1_clicked()
{
    ui->colleges->setCurrentIndex(2);
}

void tour::on_previousCOllege_2_clicked()
{
    ui->colleges->setCurrentIndex(1);
}

void tour::on_nextCollege_2_clicked()
{
    ui->colleges->setCurrentIndex(3);
}

void tour::on_previousCollege_3_clicked()
{
    ui->colleges->setCurrentIndex(2);
}

void tour::on_nextCollege_3_clicked()
{
    ui->colleges->setCurrentIndex(4);
}

void tour::on_previousCollege_4_clicked()
{
    ui->colleges->setCurrentIndex(3);
}

void tour::on_nextCollege_4_clicked()
{
    ui->colleges->setCurrentIndex(5);
}

void tour::on_previousCollege_5_clicked()
{
    ui->colleges->setCurrentIndex(4);
}

void tour::on_nextCollege_5_clicked()
{
    ui->colleges->setCurrentIndex(6);
}

void tour::on_previousCollege_6_clicked()
{
    ui->colleges->setCurrentIndex(5);
}

void tour::on_nextCollege_6_clicked()
{
    ui->colleges->setCurrentIndex(7);
}

void tour::on_previousCollege_7_clicked()
{
    ui->colleges->setCurrentIndex(6);
}

void tour::on_nextCollege_7_clicked()
{
    ui->colleges->setCurrentIndex(8);
}

void tour::on_previousCollege_8_clicked()
{
    ui->colleges->setCurrentIndex(7);
}

void tour::on_nextCollege_8_clicked()
{
    ui->colleges->setCurrentIndex(9);
}

void tour::on_previousCollege_9_clicked()
{
    ui->colleges->setCurrentIndex(8);
}

void tour::on_nextCollege_9_clicked()
{
    ui->colleges->setCurrentIndex(10);
}

void tour::on_previousCollege_10_clicked()
{
    ui->colleges->setCurrentIndex(9);
}

void tour::on_nextCollege_10_clicked()
{
    ui->colleges->setCurrentIndex(11);
}

void tour::on_previousCollege_11_clicked()
{
    ui->colleges->setCurrentIndex(10);
}

void tour::on_nextCollege_11_clicked()
{
    ui->colleges->setCurrentIndex(12);
}

void tour::on_previousCollege_12_clicked()
{
    ui->colleges->setCurrentIndex(11);
}
