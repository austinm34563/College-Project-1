#include "introductorypage.h"
#include "ui_introductorypage.h"

IntroductoryPage::IntroductoryPage(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::IntroductoryPage)
{
    ui->setupUi(this);
}

IntroductoryPage::~IntroductoryPage()
{
    delete ui;
}

void IntroductoryPage::on_adminLoginButton_clicked()
{
    adminPtr = new AdminLoginScreen(this);
    adminPtr->show();
    hide();
}

void IntroductoryPage::on_startButton_clicked()
{
    studentPtr = new StudentConsole(this);
    studentPtr->show();
    hide();
}
