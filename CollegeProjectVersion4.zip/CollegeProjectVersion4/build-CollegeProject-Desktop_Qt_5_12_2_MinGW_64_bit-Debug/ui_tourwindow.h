/********************************************************************************
** Form generated from reading UI file 'tourwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.12.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_TOURWINDOW_H
#define UI_TOURWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>

QT_BEGIN_NAMESPACE

class Ui_tourWindow
{
public:

    void setupUi(QDialog *tourWindow)
    {
        if (tourWindow->objectName().isEmpty())
            tourWindow->setObjectName(QString::fromUtf8("tourWindow"));
        tourWindow->resize(400, 300);

        retranslateUi(tourWindow);

        QMetaObject::connectSlotsByName(tourWindow);
    } // setupUi

    void retranslateUi(QDialog *tourWindow)
    {
        tourWindow->setWindowTitle(QApplication::translate("tourWindow", "Dialog", nullptr));
    } // retranslateUi

};

namespace Ui {
    class tourWindow: public Ui_tourWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_TOURWINDOW_H
