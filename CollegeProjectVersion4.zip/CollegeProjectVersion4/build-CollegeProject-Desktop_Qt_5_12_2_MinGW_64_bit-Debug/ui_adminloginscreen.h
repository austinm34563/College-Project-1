/********************************************************************************
** Form generated from reading UI file 'adminloginscreen.ui'
**
** Created by: Qt User Interface Compiler version 5.12.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ADMINLOGINSCREEN_H
#define UI_ADMINLOGINSCREEN_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_AdminLoginScreen
{
public:
    QLineEdit *usernameLine;
    QLineEdit *passwordLine;
    QLabel *label;
    QLabel *label_2;
    QPushButton *loginButton;

    void setupUi(QDialog *AdminLoginScreen)
    {
        if (AdminLoginScreen->objectName().isEmpty())
            AdminLoginScreen->setObjectName(QString::fromUtf8("AdminLoginScreen"));
        AdminLoginScreen->resize(590, 366);
        usernameLine = new QLineEdit(AdminLoginScreen);
        usernameLine->setObjectName(QString::fromUtf8("usernameLine"));
        usernameLine->setGeometry(QRect(300, 100, 113, 21));
        passwordLine = new QLineEdit(AdminLoginScreen);
        passwordLine->setObjectName(QString::fromUtf8("passwordLine"));
        passwordLine->setGeometry(QRect(300, 170, 113, 21));
        label = new QLabel(AdminLoginScreen);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(200, 100, 81, 16));
        label_2 = new QLabel(AdminLoginScreen);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(200, 170, 71, 16));
        loginButton = new QPushButton(AdminLoginScreen);
        loginButton->setObjectName(QString::fromUtf8("loginButton"));
        loginButton->setGeometry(QRect(250, 240, 113, 32));
        loginButton->setStyleSheet(QString::fromUtf8("background-color: rgb(210, 255, 177);"));

        retranslateUi(AdminLoginScreen);

        QMetaObject::connectSlotsByName(AdminLoginScreen);
    } // setupUi

    void retranslateUi(QDialog *AdminLoginScreen)
    {
        AdminLoginScreen->setWindowTitle(QApplication::translate("AdminLoginScreen", "Dialog", nullptr));
        label->setText(QApplication::translate("AdminLoginScreen", "Username", nullptr));
        label_2->setText(QApplication::translate("AdminLoginScreen", "Password", nullptr));
        loginButton->setText(QApplication::translate("AdminLoginScreen", "Login", nullptr));
    } // retranslateUi

};

namespace Ui {
    class AdminLoginScreen: public Ui_AdminLoginScreen {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ADMINLOGINSCREEN_H
