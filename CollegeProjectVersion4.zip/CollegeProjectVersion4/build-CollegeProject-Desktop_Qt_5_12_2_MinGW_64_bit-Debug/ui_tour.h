/********************************************************************************
** Form generated from reading UI file 'tour.ui'
**
** Created by: Qt User Interface Compiler version 5.12.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_TOUR_H
#define UI_TOUR_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStackedWidget>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_tour
{
public:
    QStackedWidget *stackedWidget;
    QWidget *page;
    QWidget *page_2;
    QLabel *label;
    QPushButton *backButton;

    void setupUi(QDialog *tour)
    {
        if (tour->objectName().isEmpty())
            tour->setObjectName(QString::fromUtf8("tour"));
        tour->resize(893, 608);
        stackedWidget = new QStackedWidget(tour);
        stackedWidget->setObjectName(QString::fromUtf8("stackedWidget"));
        stackedWidget->setGeometry(QRect(70, 310, 721, 221));
        page = new QWidget();
        page->setObjectName(QString::fromUtf8("page"));
        stackedWidget->addWidget(page);
        page_2 = new QWidget();
        page_2->setObjectName(QString::fromUtf8("page_2"));
        stackedWidget->addWidget(page_2);
        label = new QLabel(tour);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(280, 280, 351, 20));
        backButton = new QPushButton(tour);
        backButton->setObjectName(QString::fromUtf8("backButton"));
        backButton->setGeometry(QRect(410, 550, 75, 23));
        label->raise();
        stackedWidget->raise();
        backButton->raise();

        retranslateUi(tour);

        stackedWidget->setCurrentIndex(1);


        QMetaObject::connectSlotsByName(tour);
    } // setupUi

    void retranslateUi(QDialog *tour)
    {
        tour->setWindowTitle(QApplication::translate("tour", "Dialog", nullptr));
        label->setText(QApplication::translate("tour", "No colleges have been chosen. At least 1 must be chosen to start a tour.", nullptr));
        backButton->setText(QApplication::translate("tour", "Back", nullptr));
    } // retranslateUi

};

namespace Ui {
    class tour: public Ui_tour {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_TOUR_H
