/********************************************************************************
** Form generated from reading UI file 'introductorypage.ui'
**
** Created by: Qt User Interface Compiler version 5.12.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_INTRODUCTORYPAGE_H
#define UI_INTRODUCTORYPAGE_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_IntroductoryPage
{
public:
    QWidget *centralWidget;
    QPushButton *adminLoginButton;
    QLabel *label;
    QLabel *label_2;
    QPushButton *startButton;
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *IntroductoryPage)
    {
        if (IntroductoryPage->objectName().isEmpty())
            IntroductoryPage->setObjectName(QString::fromUtf8("IntroductoryPage"));
        IntroductoryPage->resize(768, 488);
        centralWidget = new QWidget(IntroductoryPage);
        centralWidget->setObjectName(QString::fromUtf8("centralWidget"));
        adminLoginButton = new QPushButton(centralWidget);
        adminLoginButton->setObjectName(QString::fromUtf8("adminLoginButton"));
        adminLoginButton->setGeometry(QRect(420, 320, 113, 32));
        adminLoginButton->setStyleSheet(QString::fromUtf8("background-color: rgb(221, 255, 219);"));
        label = new QLabel(centralWidget);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(130, 50, 511, 41));
        label->setStyleSheet(QString::fromUtf8("font: 24pt \".SF NS Text\";\n"
"font: 75 24pt \"Didot\";"));
        label_2 = new QLabel(centralWidget);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(280, 110, 251, 16));
        startButton = new QPushButton(centralWidget);
        startButton->setObjectName(QString::fromUtf8("startButton"));
        startButton->setGeometry(QRect(240, 320, 113, 32));
        startButton->setStyleSheet(QString::fromUtf8("background-color: rgb(180, 192, 253);"));
        IntroductoryPage->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(IntroductoryPage);
        menuBar->setObjectName(QString::fromUtf8("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 768, 22));
        IntroductoryPage->setMenuBar(menuBar);
        mainToolBar = new QToolBar(IntroductoryPage);
        mainToolBar->setObjectName(QString::fromUtf8("mainToolBar"));
        IntroductoryPage->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(IntroductoryPage);
        statusBar->setObjectName(QString::fromUtf8("statusBar"));
        IntroductoryPage->setStatusBar(statusBar);

        retranslateUi(IntroductoryPage);

        QMetaObject::connectSlotsByName(IntroductoryPage);
    } // setupUi

    void retranslateUi(QMainWindow *IntroductoryPage)
    {
        IntroductoryPage->setWindowTitle(QApplication::translate("IntroductoryPage", "IntroductoryPage", nullptr));
        adminLoginButton->setText(QApplication::translate("IntroductoryPage", "Admin Login", nullptr));
        label->setText(QApplication::translate("IntroductoryPage", "Welcome To The College Touring Experience!", nullptr));
        label_2->setText(QApplication::translate("IntroductoryPage", "Start Your Journey to Your Future Today", nullptr));
        startButton->setText(QApplication::translate("IntroductoryPage", "Start", nullptr));
    } // retranslateUi

};

namespace Ui {
    class IntroductoryPage: public Ui_IntroductoryPage {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_INTRODUCTORYPAGE_H
