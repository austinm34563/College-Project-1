/********************************************************************************
** Form generated from reading UI file 'adminpage.ui'
**
** Created by: Qt User Interface Compiler version 5.12.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ADMINPAGE_H
#define UI_ADMINPAGE_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QTableView>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_AdminPage
{
public:
    QTabWidget *tabWidget;
    QWidget *tab;
    QLineEdit *CollegeName;
    QLabel *label;
    QPushButton *addCollegeButton;
    QWidget *tab_3;
    QLineEdit *price;
    QLabel *label_8;
    QLabel *label_9;
    QLineEdit *collegeSouveName;
    QLineEdit *souvenir;
    QLabel *label_10;
    QPushButton *souvenirAddButton;
    QWidget *tab_4;
    QLineEdit *collegeDelete;
    QLabel *label_11;
    QLabel *label_12;
    QLineEdit *souvDelete;
    QPushButton *deleteSouvButton;
    QWidget *tab_6;
    QLineEdit *collegeUpdate;
    QLabel *label_13;
    QLabel *label_14;
    QLineEdit *souvenirUpdate;
    QLabel *label_15;
    QLineEdit *priceUpdate;
    QPushButton *updatePriceButton;
    QWidget *tab_5;
    QTableView *dataTable;
    QPushButton *viewCollegeButton;
    QPushButton *viewDistButton;
    QPushButton *viewSouvButton;
    QPushButton *homeButton;

    void setupUi(QDialog *AdminPage)
    {
        if (AdminPage->objectName().isEmpty())
            AdminPage->setObjectName(QString::fromUtf8("AdminPage"));
        AdminPage->resize(760, 430);
        tabWidget = new QTabWidget(AdminPage);
        tabWidget->setObjectName(QString::fromUtf8("tabWidget"));
        tabWidget->setGeometry(QRect(0, 0, 761, 451));
        tab = new QWidget();
        tab->setObjectName(QString::fromUtf8("tab"));
        CollegeName = new QLineEdit(tab);
        CollegeName->setObjectName(QString::fromUtf8("CollegeName"));
        CollegeName->setGeometry(QRect(410, 90, 113, 21));
        label = new QLabel(tab);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(260, 90, 91, 16));
        addCollegeButton = new QPushButton(tab);
        addCollegeButton->setObjectName(QString::fromUtf8("addCollegeButton"));
        addCollegeButton->setGeometry(QRect(310, 190, 113, 32));
        addCollegeButton->setStyleSheet(QString::fromUtf8("background-color: rgb(197, 255, 196);"));
        tabWidget->addTab(tab, QString());
        tab_3 = new QWidget();
        tab_3->setObjectName(QString::fromUtf8("tab_3"));
        price = new QLineEdit(tab_3);
        price->setObjectName(QString::fromUtf8("price"));
        price->setGeometry(QRect(390, 140, 113, 21));
        label_8 = new QLabel(tab_3);
        label_8->setObjectName(QString::fromUtf8("label_8"));
        label_8->setGeometry(QRect(250, 140, 111, 16));
        label_9 = new QLabel(tab_3);
        label_9->setObjectName(QString::fromUtf8("label_9"));
        label_9->setGeometry(QRect(250, 90, 111, 16));
        collegeSouveName = new QLineEdit(tab_3);
        collegeSouveName->setObjectName(QString::fromUtf8("collegeSouveName"));
        collegeSouveName->setGeometry(QRect(390, 90, 113, 21));
        souvenir = new QLineEdit(tab_3);
        souvenir->setObjectName(QString::fromUtf8("souvenir"));
        souvenir->setGeometry(QRect(390, 40, 113, 21));
        label_10 = new QLabel(tab_3);
        label_10->setObjectName(QString::fromUtf8("label_10"));
        label_10->setGeometry(QRect(250, 40, 111, 16));
        souvenirAddButton = new QPushButton(tab_3);
        souvenirAddButton->setObjectName(QString::fromUtf8("souvenirAddButton"));
        souvenirAddButton->setGeometry(QRect(310, 230, 113, 32));
        souvenirAddButton->setStyleSheet(QString::fromUtf8("background-color: rgb(254, 255, 219)"));
        tabWidget->addTab(tab_3, QString());
        tab_4 = new QWidget();
        tab_4->setObjectName(QString::fromUtf8("tab_4"));
        collegeDelete = new QLineEdit(tab_4);
        collegeDelete->setObjectName(QString::fromUtf8("collegeDelete"));
        collegeDelete->setGeometry(QRect(390, 120, 113, 21));
        label_11 = new QLabel(tab_4);
        label_11->setObjectName(QString::fromUtf8("label_11"));
        label_11->setGeometry(QRect(250, 120, 111, 16));
        label_12 = new QLabel(tab_4);
        label_12->setObjectName(QString::fromUtf8("label_12"));
        label_12->setGeometry(QRect(250, 70, 111, 16));
        souvDelete = new QLineEdit(tab_4);
        souvDelete->setObjectName(QString::fromUtf8("souvDelete"));
        souvDelete->setGeometry(QRect(390, 70, 113, 21));
        deleteSouvButton = new QPushButton(tab_4);
        deleteSouvButton->setObjectName(QString::fromUtf8("deleteSouvButton"));
        deleteSouvButton->setGeometry(QRect(310, 230, 131, 32));
        deleteSouvButton->setStyleSheet(QString::fromUtf8("background-color: rgb(253, 118, 133);"));
        tabWidget->addTab(tab_4, QString());
        tab_6 = new QWidget();
        tab_6->setObjectName(QString::fromUtf8("tab_6"));
        collegeUpdate = new QLineEdit(tab_6);
        collegeUpdate->setObjectName(QString::fromUtf8("collegeUpdate"));
        collegeUpdate->setGeometry(QRect(420, 90, 113, 21));
        label_13 = new QLabel(tab_6);
        label_13->setObjectName(QString::fromUtf8("label_13"));
        label_13->setGeometry(QRect(280, 90, 111, 16));
        label_14 = new QLabel(tab_6);
        label_14->setObjectName(QString::fromUtf8("label_14"));
        label_14->setGeometry(QRect(280, 140, 111, 16));
        souvenirUpdate = new QLineEdit(tab_6);
        souvenirUpdate->setObjectName(QString::fromUtf8("souvenirUpdate"));
        souvenirUpdate->setGeometry(QRect(420, 40, 113, 21));
        label_15 = new QLabel(tab_6);
        label_15->setObjectName(QString::fromUtf8("label_15"));
        label_15->setGeometry(QRect(280, 40, 111, 16));
        priceUpdate = new QLineEdit(tab_6);
        priceUpdate->setObjectName(QString::fromUtf8("priceUpdate"));
        priceUpdate->setGeometry(QRect(420, 140, 113, 21));
        updatePriceButton = new QPushButton(tab_6);
        updatePriceButton->setObjectName(QString::fromUtf8("updatePriceButton"));
        updatePriceButton->setGeometry(QRect(340, 230, 141, 32));
        updatePriceButton->setStyleSheet(QString::fromUtf8("background-color: rgb(212, 255, 247);\n"
""));
        tabWidget->addTab(tab_6, QString());
        tab_5 = new QWidget();
        tab_5->setObjectName(QString::fromUtf8("tab_5"));
        dataTable = new QTableView(tab_5);
        dataTable->setObjectName(QString::fromUtf8("dataTable"));
        dataTable->setGeometry(QRect(20, 30, 711, 321));
        viewCollegeButton = new QPushButton(tab_5);
        viewCollegeButton->setObjectName(QString::fromUtf8("viewCollegeButton"));
        viewCollegeButton->setGeometry(QRect(110, 360, 113, 32));
        viewCollegeButton->setStyleSheet(QString::fromUtf8("background-color: rgb(220, 229, 255);"));
        viewDistButton = new QPushButton(tab_5);
        viewDistButton->setObjectName(QString::fromUtf8("viewDistButton"));
        viewDistButton->setGeometry(QRect(290, 360, 131, 32));
        viewDistButton->setStyleSheet(QString::fromUtf8("background-color: rgb(242, 255, 225);"));
        viewSouvButton = new QPushButton(tab_5);
        viewSouvButton->setObjectName(QString::fromUtf8("viewSouvButton"));
        viewSouvButton->setGeometry(QRect(490, 360, 121, 32));
        viewSouvButton->setStyleSheet(QString::fromUtf8("background-color: rgb(254, 211, 255);"));
        tabWidget->addTab(tab_5, QString());
        homeButton = new QPushButton(AdminPage);
        homeButton->setObjectName(QString::fromUtf8("homeButton"));
        homeButton->setGeometry(QRect(660, 20, 91, 32));
        homeButton->setStyleSheet(QString::fromUtf8("background-color: rgb(254, 171, 191);"));

        retranslateUi(AdminPage);

        tabWidget->setCurrentIndex(0);


        QMetaObject::connectSlotsByName(AdminPage);
    } // setupUi

    void retranslateUi(QDialog *AdminPage)
    {
        AdminPage->setWindowTitle(QApplication::translate("AdminPage", "Dialog", nullptr));
        label->setText(QApplication::translate("AdminPage", "College Name", nullptr));
        addCollegeButton->setText(QApplication::translate("AdminPage", "Add College", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(tab), QApplication::translate("AdminPage", "Add College", nullptr));
        price->setText(QString());
        label_8->setText(QApplication::translate("AdminPage", "Price", nullptr));
        label_9->setText(QApplication::translate("AdminPage", "College Name", nullptr));
        label_10->setText(QApplication::translate("AdminPage", "Souvenir", nullptr));
        souvenirAddButton->setText(QApplication::translate("AdminPage", "Add Souvenir", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(tab_3), QApplication::translate("AdminPage", "Add Souvenirs", nullptr));
        label_11->setText(QApplication::translate("AdminPage", "College Name", nullptr));
        label_12->setText(QApplication::translate("AdminPage", "Souvenir", nullptr));
        deleteSouvButton->setText(QApplication::translate("AdminPage", "Delete Souvenir", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(tab_4), QApplication::translate("AdminPage", "Delete Souvenirs", nullptr));
        label_13->setText(QApplication::translate("AdminPage", "College Name", nullptr));
        label_14->setText(QApplication::translate("AdminPage", "Price", nullptr));
        label_15->setText(QApplication::translate("AdminPage", "Souvenir", nullptr));
        priceUpdate->setText(QString());
        updatePriceButton->setText(QApplication::translate("AdminPage", "Update Price", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(tab_6), QApplication::translate("AdminPage", "Update Prices", nullptr));
        viewCollegeButton->setText(QApplication::translate("AdminPage", "View Colleges", nullptr));
        viewDistButton->setText(QApplication::translate("AdminPage", "View Distances", nullptr));
        viewSouvButton->setText(QApplication::translate("AdminPage", "View Souvenirs", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(tab_5), QApplication::translate("AdminPage", "View Data", nullptr));
        homeButton->setText(QApplication::translate("AdminPage", "Home", nullptr));
    } // retranslateUi

};

namespace Ui {
    class AdminPage: public Ui_AdminPage {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ADMINPAGE_H
